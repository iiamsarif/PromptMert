// Mobile navigation toggle
const navToggle = document.querySelector(".nav-toggle");
const navMenu = document.querySelector(".nav-menu");
const navLinks = document.querySelectorAll(".nav-menu a");
const backToTop = document.querySelector(".back-to-top");
const form = document.getElementById("contactForm");
const formMessage = document.getElementById("formMessage");
const counters = document.querySelectorAll(".counter");
const revealItems = document.querySelectorAll(".reveal");
const tiltItems = document.querySelectorAll("[data-tilt]");
const magneticItems = document.querySelectorAll(".magnetic");
const heroPreviewCards = document.querySelectorAll("[data-hero-card]");

if (navToggle && navMenu) {
  navToggle.addEventListener("click", () => {
    const isOpen = navMenu.classList.toggle("open");
    navToggle.setAttribute("aria-expanded", String(isOpen));
    document.body.classList.toggle("nav-open", isOpen);
  });

  navLinks.forEach((link) => {
    link.addEventListener("click", () => {
      navMenu.classList.remove("open");
      navToggle.setAttribute("aria-expanded", "false");
      document.body.classList.remove("nav-open");
    });
  });
}

// Scroll-based section reveal using Intersection Observer.
const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.classList.add("in-view");
      revealObserver.unobserve(entry.target);
    }
  });
}, {
  threshold: 0.14,
  rootMargin: "0px 0px -8% 0px"
});

revealItems.forEach((item) => revealObserver.observe(item));

// Counter values animate once when the cards enter the viewport.
const counterObserver = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (!entry.isIntersecting) {
      return;
    }

    const counter = entry.target;
    const target = Number(counter.dataset.target || 0);
    const duration = 1400;
    const startTime = performance.now();

    const updateCounter = (now) => {
      const progress = Math.min((now - startTime) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      counter.textContent = Math.round(target * eased).toString();

      if (progress < 1) {
        requestAnimationFrame(updateCounter);
      }
    };

    requestAnimationFrame(updateCounter);
    counterObserver.unobserve(counter);
  });
}, {
  threshold: 0.65
});

counters.forEach((counter) => counterObserver.observe(counter));

// Back-to-top visibility and scroll behavior.
const handleScrollState = () => {
  if (backToTop) {
    backToTop.classList.toggle("visible", window.scrollY > 500);
  }
};

window.addEventListener("scroll", handleScrollState, { passive: true });
handleScrollState();

if (backToTop) {
  backToTop.addEventListener("click", () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  });
}

// Soft custom cursor with eased ring movement and hover scaling.
const cursorDot = document.querySelector(".cursor-dot");
const cursorRing = document.querySelector(".cursor-ring");
const hasFinePointer = window.matchMedia("(pointer: fine)").matches;

if (cursorDot && cursorRing && hasFinePointer) {
  let mouseX = window.innerWidth / 2;
  let mouseY = window.innerHeight / 2;
  let ringX = mouseX;
  let ringY = mouseY;

  const moveCursor = () => {
    ringX += (mouseX - ringX) * 0.16;
    ringY += (mouseY - ringY) * 0.16;

    cursorDot.style.transform = `translate3d(${mouseX - 5}px, ${mouseY - 5}px, 0)`;
    cursorRing.style.transform = `translate3d(${ringX}px, ${ringY}px, 0) translate(-50%, -50%)`;
    requestAnimationFrame(moveCursor);
  };

  window.addEventListener("mousemove", (event) => {
    mouseX = event.clientX;
    mouseY = event.clientY;
  });

  document.querySelectorAll("a, button, input, textarea, .tilt").forEach((element) => {
    element.addEventListener("mouseenter", () => cursorRing.classList.add("active"));
    element.addEventListener("mouseleave", () => cursorRing.classList.remove("active"));
  });

  requestAnimationFrame(moveCursor);
}

// Lightweight 3D tilt interaction.
tiltItems.forEach((item) => {
  item.addEventListener("mousemove", (event) => {
    const rect = item.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;
    const rotateY = ((x / rect.width) - 0.5) * 10;
    const rotateX = (0.5 - (y / rect.height)) * 10;

    item.style.transform = `perspective(1200px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-4px)`;
  });

  item.addEventListener("mouseleave", () => {
    item.style.transform = "";
  });
});

// Magnetic button motion for small premium hover feedback.
magneticItems.forEach((item) => {
  item.addEventListener("mousemove", (event) => {
    const rect = item.getBoundingClientRect();
    const x = event.clientX - rect.left - rect.width / 2;
    const y = event.clientY - rect.top - rect.height / 2;

    item.style.transform = `translate(${x * 0.08}px, ${y * 0.08}px)`;
  });

  item.addEventListener("mouseleave", () => {
    item.style.transform = "";
  });
});

// Auto-rotating hero card stack for a layered 3D showcase.
if (heroPreviewCards.length > 1) {
  let activeIndex = 0;
  let heroRotationTimer = null;
  let heroStartTimer = null;
  const heroVisual = document.querySelector(".hero-showcase");

  const renderHeroCards = (nextIndex) => {
    heroPreviewCards.forEach((card, index) => {
      card.classList.remove("is-active", "is-behind", "is-exit");

      if (index === nextIndex) {
        card.classList.add("is-active");
      } else if (index === (nextIndex + 1) % heroPreviewCards.length) {
        card.classList.add("is-behind");
      } else {
        card.classList.add("is-exit");
      }
    });

    activeIndex = nextIndex;
  };

  const rotateHeroCards = () => {
    const nextIndex = (activeIndex + 1) % heroPreviewCards.length;
    const currentCard = heroPreviewCards[activeIndex];
    currentCard.classList.remove("is-active", "is-behind");
    currentCard.classList.add("is-exit");

    window.setTimeout(() => {
      renderHeroCards(nextIndex);
    }, 220);
  };

  const startHeroRotation = () => {
    if (!heroStartTimer && !heroRotationTimer) {
      heroStartTimer = window.setTimeout(() => {
        rotateHeroCards();
        heroRotationTimer = window.setInterval(rotateHeroCards, 3800);
        heroStartTimer = null;
      }, 1000);
    }
  };

  const stopHeroRotation = () => {
    if (heroStartTimer) {
      window.clearTimeout(heroStartTimer);
      heroStartTimer = null;
    }

    if (heroRotationTimer) {
      window.clearInterval(heroRotationTimer);
      heroRotationTimer = null;
    }
  };

  renderHeroCards(0);
  startHeroRotation();

  if (heroVisual) {
    heroVisual.addEventListener("mouseenter", stopHeroRotation);
    heroVisual.addEventListener("mouseleave", startHeroRotation);
  }
}

// Subtle parallax for hero elements to reinforce depth.
const floatingShapes = document.querySelector(".floating-shapes");
const heroShowcase = document.querySelector(".hero-showcase");

const applyParallax = () => {
  const scrollY = window.scrollY;

  if (floatingShapes) {
    floatingShapes.style.transform = `translate3d(0, ${scrollY * 0.06}px, 0)`;
  }

  if (heroShowcase) {
    heroShowcase.style.transform = `translate3d(0, ${scrollY * -0.05}px, 0)`;
  }
};

window.addEventListener("scroll", applyParallax, { passive: true });
applyParallax();

// Frontend-only validation for the contact form.
if (form && formMessage) {
  form.addEventListener("submit", (event) => {
    event.preventDefault();

    const name = form.name;
    const email = form.email;
    const message = form.message;
    const fields = [name, email, message];
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    fields.forEach((field) => field.classList.remove("invalid"));

    let hasError = false;

    if (!name.value.trim()) {
      name.classList.add("invalid");
      hasError = true;
    }

    if (!email.value.trim() || !emailPattern.test(email.value.trim())) {
      email.classList.add("invalid");
      hasError = true;
    }

    if (message.value.trim().length < 12) {
      message.classList.add("invalid");
      hasError = true;
    }

    if (hasError) {
      formMessage.textContent = "Please complete all fields and provide a valid email.";
      formMessage.style.color = "#d94b70";
      return;
    }

    formMessage.textContent = "Message ready. Connect your preferred service to send submissions.";
    formMessage.style.color = "#5e35b1";
    form.reset();
  });
}
