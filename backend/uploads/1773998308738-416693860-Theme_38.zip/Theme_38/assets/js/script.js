const body = document.body;
const loader = document.getElementById("loader");
const loaderBar = document.getElementById("loaderBar");
const loaderPercent = document.getElementById("loaderPercent");
const pageShell = document.getElementById("pageShell");
const menuToggle = document.getElementById("menuToggle");
const siteNav = document.getElementById("siteNav");
const backToTop = document.getElementById("backToTop");
const revealItems = document.querySelectorAll(".reveal");
const counterItems = document.querySelectorAll(".counter");
const heroColumns = document.querySelectorAll("[data-parallax-column]");
const parallaxItems = document.querySelectorAll("[data-parallax-speed]");
const innerParallaxImages = document.querySelectorAll(".inner-parallax");
const fastScrollItems = document.querySelectorAll("[data-fast]");

body.classList.add("is-loading");

let currentScroll = 0;
let targetScroll = 0;
let loaderValue = 0;
let animationStarted = false;

function updateEffects(scrollPosition) {
  heroColumns.forEach((column) => {
    const speed = Number(column.dataset.parallaxColumn) || 0;
    column.style.transform = `translate3d(0, ${scrollPosition * speed}px, 0)`;
  });

  parallaxItems.forEach((item) => {
    const rect = item.getBoundingClientRect();
    const speed = Number(item.dataset.parallaxSpeed) || 0;
    const axis = item.dataset.parallaxAxis || "y";
    const centerOffset = rect.top - window.innerHeight * 0.5;
    const movement = centerOffset * speed;
    item.style.setProperty("--parallax-x", axis === "x" ? `${movement}px` : "0px");
    item.style.setProperty("--parallax-y", axis === "y" ? `${movement}px` : "0px");
  });

  innerParallaxImages.forEach((image) => {
    const frame = image.parentElement;
    if (!frame) {
      return;
    }

    const rect = frame.getBoundingClientRect();
    const speed = Number(image.dataset.speed) || -0.1;
    image.style.transform = `scale(1.12) translate3d(0, ${rect.top * speed}px, 0)`;
  });

  fastScrollItems.forEach((item) => {
    const rect = item.getBoundingClientRect();
    const speed = Number(item.dataset.fast) || 0.1;
    item.style.setProperty("--fast-x", "0px");
    item.style.setProperty("--fast-y", `${rect.top * speed}px`);
  });

  backToTop.classList.toggle("is-visible", scrollPosition > 600);
}

function animateScroll() {
  currentScroll = window.scrollY || window.pageYOffset;
  updateEffects(currentScroll);
  window.requestAnimationFrame(animateScroll);
}

function setupReveal() {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("is-visible");
        observer.unobserve(entry.target);
      }
    });
  }, {
    threshold: 0.18
  });

  revealItems.forEach((item) => observer.observe(item));
}

function setupCounters() {
  const counterObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (!entry.isIntersecting) {
        return;
      }

      const counter = entry.target;
      const target = Number(counter.dataset.target) || 0;
      const duration = 1400;
      const startTime = performance.now();

      function updateCounter(now) {
        const progress = Math.min((now - startTime) / duration, 1);
        counter.textContent = `${Math.floor(target * progress)}+`;
        if (progress < 1) {
          window.requestAnimationFrame(updateCounter);
        }
      }

      window.requestAnimationFrame(updateCounter);
      counterObserver.unobserve(counter);
    });
  }, {
    threshold: 0.4
  });

  counterItems.forEach((counter) => counterObserver.observe(counter));
}

function runLoader() {
  const interval = window.setInterval(() => {
    loaderValue += Math.random() * 11;
    if (loaderValue >= 100) {
      loaderValue = 100;
    }

    const roundedValue = Math.round(loaderValue);
    loaderBar.style.width = `${roundedValue}%`;
    loaderPercent.textContent = `${roundedValue}%`;

    if (roundedValue === 100) {
      window.clearInterval(interval);
      window.setTimeout(() => {
        loader.classList.add("is-hidden");
        body.classList.remove("is-loading");
      }, 350);
    }
  }, 70);
}

function setupMenu() {
  if (!menuToggle || !siteNav) {
    return;
  }

  menuToggle.addEventListener("click", () => {
    const isOpen = siteNav.classList.toggle("is-open");
    body.classList.toggle("menu-open", isOpen);
    menuToggle.setAttribute("aria-expanded", String(isOpen));
  });

  siteNav.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => {
      siteNav.classList.remove("is-open");
      body.classList.remove("menu-open");
      menuToggle.setAttribute("aria-expanded", "false");
    });
  });
}

function setupAnchors() {
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener("click", (event) => {
      const targetId = anchor.getAttribute("href");
      if (!targetId || targetId === "#") {
        event.preventDefault();
        return;
      }

      const target = document.querySelector(targetId);
      if (!target) {
        return;
      }

      event.preventDefault();
      const targetPosition = target.getBoundingClientRect().top + window.scrollY - 110;
      window.scrollTo({
        top: targetPosition,
        behavior: "smooth"
      });
    });
  });
}

function handleResize() {
  currentScroll = window.scrollY || window.pageYOffset;
  updateEffects(currentScroll);
}

window.addEventListener("resize", handleResize);
window.addEventListener("load", () => {
  setupReveal();
  setupCounters();
  setupMenu();
  setupAnchors();
  runLoader();
  currentScroll = window.scrollY || window.pageYOffset;
  updateEffects(currentScroll);
  animationStarted = true;
  window.requestAnimationFrame(animateScroll);
});

window.addEventListener("scroll", () => {
  currentScroll = window.scrollY || window.pageYOffset;
  updateEffects(currentScroll);
});

backToTop.addEventListener("click", () => {
  window.scrollTo({
    top: 0,
    behavior: "smooth"
  });
});

document.querySelector(".contact-form")?.addEventListener("submit", (event) => {
  event.preventDefault();
});
