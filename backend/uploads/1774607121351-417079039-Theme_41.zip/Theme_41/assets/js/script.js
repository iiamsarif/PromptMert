const qs = (sel, ctx = document) => ctx.querySelector(sel);
const qsa = (sel, ctx = document) => Array.from(ctx.querySelectorAll(sel));

const mobileToggle = qs('.menu-toggle');
const mobileMenu = qs('.mobile-menu');
if (mobileToggle && mobileMenu) {
  mobileToggle.addEventListener('click', () => {
    mobileMenu.classList.toggle('active');
  });
}

const heroSlides = qsa('.hero-slide');
let heroIndex = 0;
const heroAnims = ['slide-left', 'fade-in', 'slide-right'];

function showHeroSlide(index) {
  heroSlides.forEach((slide, i) => {
    slide.classList.remove('active', 'slide-left', 'fade-in', 'slide-right');
    if (i === index) {
      slide.classList.add('active', heroAnims[i % heroAnims.length]);
    }
  });
}

if (heroSlides.length) {
  showHeroSlide(heroIndex);
  setInterval(() => {
    heroIndex = (heroIndex + 1) % heroSlides.length;
    showHeroSlide(heroIndex);
  }, 4500);
}

const revealItems = qsa('.reveal');
if (revealItems.length) {
  const observer = new IntersectionObserver(
    entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('in-view');
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.2 }
  );

  revealItems.forEach(item => observer.observe(item));
}

const galleryMain = qs('.gallery-main img');
const galleryThumbs = qsa('.gallery-thumbs img');
if (galleryMain && galleryThumbs.length) {
  galleryThumbs.forEach(thumb => {
    thumb.addEventListener('click', () => {
      galleryThumbs.forEach(t => t.classList.remove('active'));
      thumb.classList.add('active');
      galleryMain.src = thumb.src;
    });
  });
}

const carouselTrack = qs('.carousel-track');
const prevBtn = qs('.carousel-prev');
const nextBtn = qs('.carousel-next');
if (carouselTrack && prevBtn && nextBtn) {
  prevBtn.addEventListener('click', () => {
    carouselTrack.scrollBy({ left: -260, behavior: 'smooth' });
  });
  nextBtn.addEventListener('click', () => {
    carouselTrack.scrollBy({ left: 260, behavior: 'smooth' });
  });
}

const qtyRows = qsa('.qty');
const totalValue = qs('[data-total]');
function updateCartTotal() {
  if (!totalValue) return;
  let total = 0;
  qsa('.cart-item').forEach(item => {
    const price = parseFloat(item.dataset.price || '0');
    const qty = parseInt(qs('.qty span', item).textContent, 10);
    total += price * qty;
  });
  totalValue.textContent = `$${total.toFixed(2)}`;
}

if (qtyRows.length) {
  qtyRows.forEach(row => {
    const minus = qs('[data-minus]', row);
    const plus = qs('[data-plus]', row);
    const value = qs('span', row);
    minus.addEventListener('click', () => {
      const current = Math.max(1, parseInt(value.textContent, 10) - 1);
      value.textContent = current;
      updateCartTotal();
    });
    plus.addEventListener('click', () => {
      const current = parseInt(value.textContent, 10) + 1;
      value.textContent = current;
      updateCartTotal();
    });
  });
}

qsa('[data-remove]').forEach(button => {
  button.addEventListener('click', () => {
    const item = button.closest('.cart-item');
    if (item) item.remove();
    updateCartTotal();
  });
});

updateCartTotal();
