document.addEventListener("DOMContentLoaded", () => {
  const body = document.body;
  const navToggle = document.querySelector(".nav-toggle");
  const mainNav = document.getElementById("mainNav");

  if (navToggle && mainNav) {
    navToggle.addEventListener("click", () => {
      const isOpen = body.classList.toggle("nav-open");
      navToggle.setAttribute("aria-expanded", String(isOpen));
    });

    mainNav.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        body.classList.remove("nav-open");
        navToggle.setAttribute("aria-expanded", "false");
      });
    });
  }

  const animatedNodes = document.querySelectorAll("[data-animate]");
  if ("IntersectionObserver" in window && animatedNodes.length) {
    const observer = new IntersectionObserver((entries, obs) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add("in-view");
        obs.unobserve(entry.target);
      });
    }, {
      threshold: 0.15,
      rootMargin: "0px 0px -40px 0px"
    });

    animatedNodes.forEach((node, index) => {
      node.style.transitionDelay = `${Math.min(index * 45, 220)}ms`;
      observer.observe(node);
    });
  } else {
    animatedNodes.forEach((node) => node.classList.add("in-view"));
  }

  const mainProductImage = document.getElementById("mainProductImage");
  const thumbs = document.querySelectorAll(".thumb");
  if (mainProductImage && thumbs.length) {
    thumbs.forEach((thumb) => {
      thumb.addEventListener("click", () => {
        thumbs.forEach((item) => item.classList.remove("is-active"));
        thumb.classList.add("is-active");
        mainProductImage.src = thumb.dataset.image || mainProductImage.src;
        mainProductImage.alt = thumb.dataset.alt || mainProductImage.alt;
      });
    });
  }

  const imageModal = document.getElementById("imageModal");
  const imageModalPhoto = document.getElementById("imageModalPhoto");
  const imageModalTitle = document.getElementById("imageModalTitle");
  const imageModalDescription = document.getElementById("imageModalDescription");

  if (imageModal && imageModalPhoto && imageModalTitle && imageModalDescription) {
    const closeModal = () => {
      imageModal.classList.remove("is-open");
      imageModal.setAttribute("aria-hidden", "true");
      body.classList.remove("modal-open");
    };

    document.querySelectorAll(".stacked-mosaic .mosaic-card").forEach((card) => {
      card.addEventListener("click", () => {
        const image = card.dataset.popupImage;
        const title = card.dataset.popupTitle || "Editorial image";
        const copy = card.dataset.popupCopy || "";
        if (!image) return;

        imageModalPhoto.src = image;
        imageModalPhoto.alt = title;
        imageModalTitle.textContent = title;
        imageModalDescription.textContent = copy;
        imageModal.classList.add("is-open");
        imageModal.setAttribute("aria-hidden", "false");
        body.classList.add("modal-open");
      });
    });

    imageModal.querySelectorAll("[data-close-modal]").forEach((element) => {
      element.addEventListener("click", closeModal);
    });

    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape" && imageModal.classList.contains("is-open")) {
        closeModal();
      }
    });
  }

  document.querySelectorAll("[data-quantity]").forEach((control) => {
    const input = control.querySelector("input");
    const buttons = control.querySelectorAll("button[data-action]");
    if (!input || !buttons.length) return;

    buttons.forEach((button) => {
      button.addEventListener("click", () => {
        const currentValue = Number.parseInt(input.value, 10) || 1;
        const nextValue = button.dataset.action === "increase" ? currentValue + 1 : Math.max(1, currentValue - 1);
        input.value = String(nextValue);
      });
    });
  });

  document.querySelectorAll(".newsletter-form").forEach((form) => {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      const button = form.querySelector("button");
      if (!button) return;

      const originalText = button.textContent;
      button.textContent = "Subscribed";
      button.disabled = true;

      window.setTimeout(() => {
        button.textContent = originalText;
        button.disabled = false;
        form.reset();
      }, 1800);
    });
  });
});
